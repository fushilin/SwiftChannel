//
//  PCHHeader.swift
//  moyo-ceshi-01
//
//  Created by 我演示 on 2019/7/9.
//  Copyright © 2019 世霖mac. All rights reserved.
//


import UIKit

///背景测试的信息写入

let textUrlString = "https://jsonplaceholder.typicode.com/posts"

