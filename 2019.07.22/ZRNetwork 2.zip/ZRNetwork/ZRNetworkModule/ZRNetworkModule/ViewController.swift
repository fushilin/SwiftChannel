//
//  ViewController.swift
//  jerry-ceshi-sorkect
//
//  Created by 我演示 on 2019/7/12.
//  Copyright © 2019 我演示. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    let socket = WebsocketManager.default
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // print(self.sign.jerry_socketIsConnert())
        
        //        self.view.backgroundColor =  UIColor.green
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       socket.connect()
        
     
        
        
    }
    
    /**
     内容信息测试通过之后，再形成对应的处理
     */
    
    
    
}

