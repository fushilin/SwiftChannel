//
//  ZRSocketRequestModel.swift
//  jerry-ceshi-sorkect
//
//  Created by 我演示 on 2019/7/17.
//  Copyright © 2019 我演示. All rights reserved.
//

import Foundation
import UIKit
import ZRBase
/*
public  class ZRSocketRequestModel {
    
    var path: String?
    
    var param :[String : Any]?
    
    
    /**
     "req_id" : "a8014a60-28e2-4913-b90e-ef54b7c705e3",
     "path" : "auth.auth",
     "language" : "ZN",
     "version" : "1.0.0"
     
     
     
     " " : "ed87ff5f-ba91-402e-ae06-08d22d1a6d72",
     "timestamp" : 1563262278825,
     "token" : "958fc42201d190b4366692442ae4bc49"
     
     
     token:  deviceID + timestamp +  后台给的串，固定(069de7990c0c4b8d87f516b7478e9f4a)  生成MD5信息{
     deviceID   设备唯一表示
     timestamp : 手机本地时间戳
     req_id (UUID 自己生成)
     }
     */
    
    var header = "header"
    
    var req_id = "req_id"
    var req_id_content: String!
 var    path = "path"
    var    path_content = "auth.auth"
    
 var    language = "language"
    var language_content =  "ZN"
    
 var    version = "version"
    var version_content = "1.0.0"
    
var  dev_id = "dev_id"
    var dev_id_content = "ed87ff5f-ba91-402e-ae06-08d22d1a6d88"
 var timestamp = "timestamp"
    var timestamp_content:TimeInterval?
var     token = "token"
    var token_content: String = ""
//        = "958fc42201d190b4366692442ae4bc49"
    
 var body = "body"
    
 public   func creatUUID() -> String {
        return "haha"
    }
    
    ///获取设备的唯一标识
    public func requestDeviceId() ->String {
        
//        req_id_content =  UIDevice.current.identifierForVendor!.uuidString
     req_id_content  =  "ed87ff5f-ba91-402e-ae06-08d22d1a6d88"
        
        return req_id_content
    }
    
    ///获取时间戳的位置
    public func requestTimeStampString() -> String {
        let now = NSDate()
        
        let timeInterval:TimeInterval = now.timeIntervalSince1970
        print("-----时间戳-------\(timeInterval)")
        
        let time = Int64(timeInterval * 1000)
        
        let useString = String(time)
        print("=========时间戳转字符串\(useString)")
        return useString
        
    }
    
//    public func requestTimeStampDouble() -> Double{
//        let now = NSDate()
//
//        let timeInterval:TimeInterval = now.timeIntervalSince1970
//        print("------------\(timeInterval)")
//
//        let time = Int64(timeInterval * 1000.0)
//        let timeDouble = Double(time)
//        return timeDouble
//
//    }
    
    public func requestToken() -> Array<Any>{
     
        let useString = "069de7990c0c4b8d87f516b7478e9f4a"
        let deivce = self.requestDeviceId()
        let timeStamp = self.requestTimeStampString()
//        let pingjieStr = deivce + timeStamp + useString
        
           let pinjieStr = deivce + timeStamp + useString
//            "ed87ff5f-ba91-402e-ae06-08d22d1a6d72" + "1563348631799"  + "069de7990c0c4b8d87f516b7478e9f4a"
//
        
        print("=====三者拼接数据===========\(pinjieStr)")
        let pinjieMD5 = pinjieStr.md5()
        print("-------MD5加密数据-----------\(pinjieMD5)")

        return [timeStamp,pinjieMD5]
    }
}
*/
