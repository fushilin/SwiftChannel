//
//  ZRSocketMakeDict.swift
//  jerry-ceshi-sorkect
//
//  Created by 我演示 on 2019/7/17.
//  Copyright © 2019 我演示. All rights reserved.
//


/// 获取uuid

/*
public class ZRSocketMakeDict {
    

    func makeArray() -> Dictionary<String , Any> {

        let array: Dictionary<String, Any>?
        
        ///内容的dict
        let ZRmodel =  ZRSocketRequestModel.init()
   
        let timeArray = ZRmodel.requestToken()
        
        let token = timeArray[1]
        
        let time = timeArray[0]
        let timeStamp = Double(time as! String)
//            timeArray[0]
        
        
        
//        let timeStamp = ZRmodel.requestTimeStampDouble()
        
//        let timeStamp  = ZRmodel.requestToken()
        
        let body = [ZRmodel.dev_id:ZRmodel.dev_id_content,
                    ZRmodel.timestamp:timeStamp as Any,
                    ZRmodel.token:token
            ] as [String : Any]
        
        let bodyDict = [ZRmodel.body : body]
        
        
        let header = [ZRmodel.req_id: ZRmodel.req_id_content,
                      ZRmodel.path:ZRmodel.path_content,
                      ZRmodel.language: ZRmodel.language_content,
                      ZRmodel.version : ZRmodel.version_content,
                      
                      ]
        

        array = [ZRmodel.header:header,ZRmodel.body:body]
        
        return array!
        
    }
    
 
 
    
//    var key: ZRSocketModel.heade
}
*/
