//
//  WebsocketManager.swift
//  ZRNetworkModule
//
//  Created by lam on 2019/7/17.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ZRBase
import Starscream
import ObjectMapper
import Gzip
//import  



/// 自定义请求错误
public enum WSError: Error {
    case timeout
}

public typealias WSBlock = (_ requestRst: WSRequestResult)->()

/// 请求结果
public enum WSRequestResult {
    case success(Any)
    case failure(Error)
}


public protocol WebsockerPacketStatusErrorType {
    //     定时器关闭
    var connerError : String {get }
    var connerInBackGround: String{get}
}
/// 请求数据协议
public protocol WSTargetType {
    var path: String { get }
    var param: [String : Any]? { get }
}

private enum WSAuthTarget {
    case auth(dev_id: String, timestamp: String, signKey: String)
}

extension WSAuthTarget : WSTargetType {
    var path: String {
        switch self {
        case .auth:
            return "auth.auth"
        }
    }
    
    var param: [String : Any]? {
        switch self {
        case .auth(let dev_id, let  timestamp, let  signKey):
                var param = [String: Any]()
                param["dev_id"] = dev_id
                param["timestamp"] =  Double(timestamp)
                let token = (dev_id + String(timestamp) + signKey).md5()
                 param["token"] = token
                
                print("=====param=====\(param)")
                
                return param
            
        default:
            return nil
        }
    }
}

fileprivate class WSResponse:NSObject, Mappable {
    public var code: String?
    public var msg: String?
    public var path: String?
    public var resp_id: String?
    
    required public init?(map: Map) {
        if map.JSON["path"] == nil, map.JSON["code"] == nil, map.JSON["resp_id"] == nil{
            return nil
        }
    }
    
    public func mapping(map: Map) {
        code <- map["code"]
        msg  <- map["msg"]
        path <- map["path"]
        resp_id <- map["resp_id"]
    }
    
    //父类的init方法是必须去实现的
    override init() {
        super.init()
    }
    
    required convenience public init?(coder aDecoder: NSCoder) {
        self.init()
    }
    
    func encode(with aCoder: NSCoder) {
        
    }
}


public enum WebsocketStatus {
    case unConnect
    case connecting
    case connected
}

open class WebsocketManager {
//    let WSAddr = "ws://192.168.1.111:1949"
    ///三分钟时间的间隔

 let WSAddr = "ws://192.168.1.111:1949"
    
    ///x重新连接的计数器
    private var reconnectCount = 0
 
    /// socket
    fileprivate var  socket :WebSocket
    
    /// 默认未连接
    public var status :WebsocketStatus = .unConnect
    /// req id
    public var req_id = 0
    
    private var packets: [WebsocketPacket] = [WebsocketPacket]()
    
    /// 静态初始化
    public static let `default`: WebsocketManager = WebsocketManager()
    
///====================================================================================================================================================
    //MARK:- 心跳包属性位置
    /// 心跳包定时器发送技术
    private var heartBeatTimer:Timer?
    private var heartBeatsConut: NSInteger! = 0
    ///发送心跳包的时间，十秒ping一次数据
    
    var PingDuration = 3
private var heartGcdTimer: DispatchSourceTimer?

    
    
    private init(){
        self.socket = WebSocket.init(url: URL(string: WSAddr)!)
        self.socket.delegate = self
        self.socket.disconnect(forceTimeout: 20, closeCode: 12)
    }

    
    /// 连接
    public func connect() {
        if status == .unConnect {
            socket.connect()
            status = .connecting
        }
    }
    
    ///2: 创建连接

    
    ///重新建立j连接的办法 首先判断是不是已经在连接了，要用一个东西去处理，比如说字节进行记录 ,在非使用状态下
    /// 3： 断开连接， 判断条件，如果断开连接，调用情况下才重新连接，或者自动重新连接，这个地方。
    ///3.1 断开连接
    ///3.2 手机进入后台，不自动连接

    
    ///4： 进行重连的样式
    ///4.1 在自动断开的情况下，进行重连，z首先判断是不是存在连接
    ///4.2 在后台的情况下，不进行重新连接

    
    ///5： 判断心跳包开始

    ///6: 心跳包停止
  
    ///6: 超时处理信息
    
    /// 发送数据入口
    public func send<T: WSTargetType>(_ target:T, block: @escaping WSBlock) {
        let path = target.path
        let param = target.param
        self.sendMassge(path, param: param, block: block)
    }
    
    /**
     case connerError
     case connerInBackGround
     */
    private func sendMassge(_ path: String, param: [String : Any]?, block:  @escaping WSBlock) {
        self.req_id  += 1
        let packet  = WebsocketPacket(path: path, param: param, req_id: self.req_id,block: block)

        print("------packert-----\(packet.packet())")
        
        packet.startTimer { [weak self] in
            packet.block?(.failure(WSError.timeout))
        }
        let data = packet.packet().data(using: .utf8)

        print("=====string => data=\(data)")
        let postData = try! data?.gzipped()
        
        print("======postData==\(postData)")

    }
    ///数据包的清查与处理 数据匹配对应，进行数据清理
 private  func  sendResonse<T: WSResponse>(_ targect: T, block: (()->Void)) {
     let path  = targect.path ?? ""
    let resq_id  = Int(targect.resp_id ??  "-1")!
    //开始执行数据便利
    let filters = self.packets.filter{ (packet) -> Bool in
        if path == packet.path, resq_id == packet.req_id {
         
            //再发送一条数据.这个位置应该存在订阅数据的解析
        self.wirteMessage()
            return true
        }
        return false
    }

    
    if filters.count > 0, let first = filters.first, let index = self.packets.firstIndex(of: first) {
        first.block?(.success("数据成功"))
        first.stopTimer()
        self.packets.remove(at: index)

    }
    
    }
    
    private func wirteMessage(){
        print("处理不同的数据")
        let array = NSMutableArray()
        array.add("/topic/00681")
        array.add("/topic/00029")
        //   1： 这个位置进行数据简化，外界只传递一个array，内部数据自己处理信息
        // 数据验证成功x之后，系统进行数据传递写入，这个位置由外界传入
        
        let optionData = WebSorkectOptionData.init(topics: array, req_id: "1253")
        socket.write(string: optionData.optionDataJson())
    }
    
}


extension WebsocketManager: WebSocketDelegate {
    
    /// 连接完成
    public func websocketDidConnect(socket: WebSocketClient) {
        ///
//        self.status = .connected
        /// 第四步： 开始心跳包的应用
        self.creatHeartBeats()
        
        /// 应用层
        self.send(WSAuthTarget.auth(dev_id: UIDevice.UUID ?? "", timestamp: String(Int64(Date().timeIntervalSince1970 * 1000.0)), signKey: "069de7990c0c4b8d87f516b7478e9f4a")) { rst in
            print("----------------认证完成")
            
            switch rst {
                /// 成功
            case .success(let obj):
                print("成功后获取的数据: \(obj)")
                break
                
                /// 失败
            case .failure(_):
                break
            }
            
        }
    }
    
    /// 断开连接
    public func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        
        /// 手动断开
        if error == nil {
            
            /// 异常断开
        } else {
            
        }

        
    }
    
    
    /// 接收 string数据
    public func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {

                  ///把数据判断交给外界处理
        if let reps = Mapper<WSResponse>().map(JSONString: text) {
            print("发请求返回相对应的响应包--------------\(text)")
            
  
            self.sendResonse(reps) {
            }
            /// 接收服务器主动推送的数据 通知
        } else if let notif = WSNotificationResponse(JSONString: text) {
            print("接收服务器主动推送的数据,判断数据类型")
            
            /// 数据正确
            if let path = notif.header?.path {
                
                /// 拼接外界需要数据
                let model = WSNotificationModel(path: path, req_id: notif.header?.req_id, data: notif.body)
                /// 发送通知
            }
            /// 其他未知数据
        } else {
            
        }
        print("websocketDidReceiveMessage \(self.packets)")
    }
    
    // 接收二进制数据
    public func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        print("websocketDidReceiveData")
        print(data)
    }

}
extension WebsocketManager{
    func creatHeartBeats(){
        switch status {
        case .connected:
            if self.heartGcdTimer == nil{
                self.creatHeartBeatsBingo()
            }
            else {
                self.closeBeatsHeartBingo()
                ///2 ： 抛出心跳包结束的信息,需要抛出什么数据？
            }
            break
        case .unConnect:
            ///去跳出对应的心跳包信息.i并且清空数据
            self.closeBeatsHeartBingo()
            self.packets.removeAll()
            break

        default:
            break
        }
 
    }
    
    
    //MARK - 创建心跳包
        
    func creatHeartBeatsBingo() {
        self.heartBeatsConut = 0
        
        self.heartGcdTimer = DispatchSource.makeTimerSource(flags: [], queue: DispatchQueue.global())
        ///这个应该是定时时间的
        self.heartGcdTimer?.schedule(deadline: DispatchTime.now(), repeating: 1)
        //循环执行，马上开始，间隔为1s,误差允许10微秒
//        self.heartGcdTimer?.scheduleRepeating(deadline: DispatchTime.now(), interval: .seconds(countDownFrequency), leeway: .milliseconds(10))
    
        self.heartGcdTimer?.setEventHandler(handler: {
            ///任务处理？
            if self.PingDuration <= 0  {
                self.heartBeatsConut += 1
                self.PingDuration = 3
                print("====(self.heartBeatsConut)====\(self.heartBeatsConut)")
                ///5 发送ping包，对应pong数据梳理≥同时如果正确 ，heartBeatsCount数据 == 0 恒等0数据
//                怎么去查看信息？？ heartCount的信息返回验证在哪里 ，发送sorkect的ping 信息
            }else{
                ///倒计时
                if  self.heartBeatsConut <= 3 {
                    DispatchQueue.main.async {
                        self.PingDuration -= 1
                        print("=== self.PingDuration ====self\( self.PingDuration)")
                    }
                }else{
                    //                         关闭定时器，关闭信息 .取消定时器
                    self.heartBeatsConut = 0
                    self.heartGcdTimer?.cancel()
                    self.heartGcdTimer =  nil
                    ///5: 通过验证 .抛出数据
                }
            }
        })
        ///这一句话是立即开始执行
          self.heartGcdTimer?.resume()
        self.heartGcdTimer?.schedule(deadline: DispatchTime.now(), repeating: 1)
        }
    //MARK: -  关闭心跳包
    func  closeBeatsHeartBingo(){
         if self.heartGcdTimer != nil {
            self.heartGcdTimer?.resume()
            self.heartGcdTimer?.cancel()
             self.heartGcdTimer?.schedule(deadline: DispatchTime.now(), repeating: 1)
            ///计数器归0 强制归0 不再进行心跳
            self.heartBeatsConut = 0
        }
    }
}
