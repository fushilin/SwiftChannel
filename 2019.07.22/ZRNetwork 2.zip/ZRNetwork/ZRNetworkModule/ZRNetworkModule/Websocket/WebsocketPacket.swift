//
//  WebsocketPacket.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/17.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ZRBase
/*
 {
 "body" : {
 "dev_id" : "ed87ff5f-ba91-402e-ae06-08d22d1a6d72",
 "timestamp" : 1563348491880,
 "token" : "4940b5c2b6c3b10926b140f5d2503f2b"
 },
 "header" : {
 "language" : "ZN",
 "path" : "auth.auth",
 "req_id" : "28C88C50-0157-47C6-8316-9912C72ADCCD",
 "version" : "1.0.0"
 }
 }
 */



class WebsocketPacket: NSObject {
    
    
    
    // MARK:-定时器任务信息时间戳   =================
    
    //定义定时器
    public var GCDTimer : DispatchSourceTimer?
    //间隔时间信息
    private var timeInter : TimeInterval = 5
    
    // MARK:-定时器任务信息时间戳结束   =================
    ///定时器的状态判断
    private var isSuppend: Bool = false

    typealias PacketBlock = () -> Void

    public var path: String  = ""
    
    public var param: [String : Any]?
    
    public var req_id: Int = 0
    
    
    public var block : WSBlock?
    
    public init(path: String, param:  [String : Any]?, req_id: Int, block:WSBlock?) {
        self.param = param
        self.path = path
        self.req_id = req_id
        self.block = block
    
        super.init()
    }
    
    ///定时器彻底销毁的位置
    deinit {
        
    }
    
    public func packet() -> String {
        var header = [String : Any]()
    
        header["req_id"] = String(self.req_id)
        
        header["path"] = self.path
        
        header["language"] = "ZN"
//            LanguageManager.default.serverLanuage
        
        header["version"]  = Bundle.main.infoDictionary?["CFBundleVersion"] ?? ""
        
        var dic = [String : Any]()
        
        dic["header"] = header
        
        dic["body"] = param ?? [:]
        
        
        if let  data = try? JSONSerialization.data(withJSONObject: dic, options: []), let json = String(data: data, encoding: .utf8)  {
            
            return json
        }
        return ""
    }
    
    
    ///开启全局定时器任务  back的数据可以是。connerc的一种，这样子可以直接
    
    public func startTimeWithType(_ back: (()->WebsockerPacketStatusErrorType)){
//        self.GCDTimerCreateText(timeInterval: timeInter) { () -> WebsockerPacketStatusErrorType in
//
//            WebsockerPacketStatusErrorType.connerInBackGround
//
//        }
    }
    public func startTimer(_ back: @escaping (()->Void)) {

//        back()
        ///首先创建定时器,.然后进行使用
//        self.GCDTimerCreate(timeInterval: timeInter) {
//            back()
//        }
        
//        self.GCDTimerCreate(timeInterval: timeInter, handleBlock: <#T##(() -> Void)##(() -> Void)##() -> Void#>)
        
//        self.GCDTimerCreateText(timeInterval: timeInter) { () -> WebsockerPacketStatusErrorType in
//            WebsockerPacketStatusErrorType.connerInBackGround
//
//        }
    }
    
    ///结束定时器任务
    public func stopTimer() {
        
        self.stopOrStopGCDTimer(isStop: false)
    }
    
    public func packetsVerifyPathAndReqid(reqPath: NSString, resq_id: Int ) -> Bool{
        if self.path == reqPath as String, self.req_id == resq_id {
         
            return true
        }
        return false
        
    }
    
    
    
}
// 判断多久到了时间，处理信息
extension  WebsocketPacket{
    
    /*
    func GCDTimerCreateText<T : WebsockerPacketStatusErrorType> (timeInterval:TimeInterval ,handleBlock: @escaping (() -> Any?)) {
        
    
            //如果10秒没有返回值，那么就进行异常处理，关闭对应的服务器
            var totalTime = 10
            if self.GCDTimer == nil {
                self.GCDTimer = DispatchSource.makeTimerSource(flags: [], queue: DispatchQueue.global())
                self.GCDTimer?.schedule(deadline: DispatchTime.now(), repeating: timeInterval)
                
                
                
                self.GCDTimer?.setEventHandler(handler: {
                    
                    if totalTime <= 0 {
                        self.GCDTimer?.cancel()
                        self.GCDTimer = nil
                        print("----totalTime----\(totalTime)")
//                         数据超时十秒就抛出数据 按照数据类型匹配度
                        switch WebsockerPacketStatusErrorType.self{
                        case .connerError:
                         
                            break
                        default:
                            break
                        }
                    
                        
                        
                    }else{
                        DispatchQueue.main.async {
                            //  判断和接收系统是不是处在后台的位置，如果是的话，就直接不抛出信息，如果不是，抛出给前台处理 这个只是处理
                            totalTime -= 1
                        }
                    }

                })
                self.GCDTimer?.resume()
                //开始定时器任务信息，但是应该BLOCK什么信息呢？
                
                self.GCDTimer?.schedule(deadline: DispatchTime.now(), repeating: timeInterval)
            }else {
                
                self.stopOrStopGCDTimer(isStop: false)
            }
  
        
    }
 */
    
//    func GCDTimerCreate(timeInterval:TimeInterval ,handleBlock: @escaping (() -> Void)){
//        //如果10秒没有返回值，那么就进行异常处理，关闭对应的服务器
//        var totalTime = 10
//        if self.GCDTimer == nil {
//            self.GCDTimer = DispatchSource.makeTimerSource(flags: [], queue: DispatchQueue.global())
//        self.GCDTimer?.schedule(deadline: DispatchTime.now(), repeating: timeInterval)
//
//
//            self.GCDTimer?.setEventHandler(handler: {
//
//                if totalTime <= 0 {
//                    self.GCDTimer?.cancel()
//                    self.GCDTimer = nil
//                    print("----totalTime----\(totalTime)")
//
//                }else{
//                    DispatchQueue.main.async {
//                        //  判断和接收系统是不是处在后台的位置，如果是的话，就直接不抛出信息，如果不是，抛出给前台处理
//
//                        handleBlock()
//
//                        totalTime -= 1
//                           print("----totalTime----\(totalTime)")
//                    }
//                }
//
//
//            })
//            self.GCDTimer?.resume()
//        //开始定时器任务信息，但是应该BLOCK什么信息呢？
//
//            self.GCDTimer?.schedule(deadline: DispatchTime.now(), repeating: timeInterval)
//        }else {
//
//            self.stopOrStopGCDTimer(isStop: false)
//        }
//    }
    ///启动定时器的方法
    func stopOrStopGCDTimer(isStop: Bool){
        guard self.isSuppend != isStop else {
            return
        }
        isStop == true ? self.GCDTimer?.suspend() : self.GCDTimer?.resume()
        self.isSuppend = isStop
        
    }
    
    ///彻底销毁定时器
    
    func invallGCDTimer() {
        if self.isSuppend == true {
            
            self.GCDTimer?.resume()
        }
        self.GCDTimer?.cancel()
        self.GCDTimer = nil
    }
    
    
    ///方法补充，确定数据是不是正常的数据，是不是符合规格

    
    
    
}


/**
 面两种操作会造成程序崩溃, 原因是: gcdTimer执行了suspend()操作后, 是不可以被直接释放的, 如果想关闭一个执行了suspend()操作的计时器, 需要先执行resume(), 再执行cancel(), 最后置nil.
 // 开启计时器
 gcdTimer?.resume()
 
 // 暂停计时器
 gcdTimer?.suspend()
 // 暂停后重启计时器
 gcdTimer?.resume()
 
 // 关闭计时器
 gcdTimer?.cancel()
 gcdTimer = nil
 
 */
