//
//  Text.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/19.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit

class Text: NSObject {

    ///首先创建定时器方法
    ///1: 首先创建定义定时器的方法
    
    //      同样需要一个定时器的时间任务信息
    
    /**
     - parameter: deadline 截止时间, 计时器最迟开始时间;
     
     - parameter: wallDeadline 截止时间, 计时器最迟开始时间;
     
     - parameter: repeating 时间间隔;
     
     - parameter: leeway 容忍时间;
     */

    
}
