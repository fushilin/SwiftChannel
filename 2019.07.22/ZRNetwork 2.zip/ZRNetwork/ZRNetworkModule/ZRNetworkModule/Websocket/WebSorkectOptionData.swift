//
//  WebSorkectOptionData.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/18.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ObjectMapper
public class WebSorkectOptionData: NSObject{
    
    /**
     {
     "header" : {
     "req_id" : "866f77c4-13e8-438a-a50f-209beb53728c",
     "path" : "topic.reBind",
     "language" : "ZN",
     "version" : "1.0.0"
     },
     "body" : {
     "topics" : [ "/topic/00637", "/topic/00889", "/topic/00746", "/topic/01827", "/topic/00120", "/topic/01382", "/topic/00801", "/topic/00339", "/topic/01603", "/topic/01425", "/topic/01481", "/topic/00681", "/topic/00243", "/topic/01813", "/topic/01998", "/topic/01646", "/topic/00029", "/topic/01036", "/topic/00751", "/topic/00227" ]
     }
     }
     */
    
    var req_id: String? = "1"
    var path : String? = "topic.reBind"
    var language: String? = "ZN"
    var version: String? = "1.0"
    var bodyDict : [String:Any]?
    
//    var topics: String? = "topic"
    
///    var topicsArray: NSMutableArray? 这个由外界传递就可
    
    
    var topics: Array<Any>? 
    
    func optionDataJson() -> String {
        
        var header = [String:Any ]()
        header["req_id"] = self.req_id ?? ""
        header["path"] = self.path
        header["language"] = self.language
        header["version"] = "1.0.0"
        
        var dict  = [String: Any]()
        dict["header"] = header
        
        var toplicsDict = [String:Any] ()
        toplicsDict["topics"] = topics
        
        
        dict["body"] = toplicsDict
//            bodyDict ?? [:]
        
        if let data = try? JSONSerialization.data(withJSONObject: dict, options: []), let json = String(data: data, encoding: .utf8){
            return json
        }
        return ""
        
    }


    
//     实例化对象，进行参数使用
    public init(bodyDict:[String : Any]? ,req_id: String){
        self.bodyDict = bodyDict
        self.req_id = req_id
        super.init()
    }
    public init(topics:Any? ,req_id: String){
        self.topics = topics as! Array<Any>
        self.req_id = req_id
        
    }
    
    deinit {
        
    }
}
