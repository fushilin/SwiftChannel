//
//  WebsocketManagerClassModel.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/19.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import  Foundation
import ObjectMapper
import ZRBase
import Starscream
import ObjectMapper


public class WSNotificationResponse:NSObject, Mappable {
    
    var header: WSNotificationResponseHeader?
    var body: Any?
    
    required public init?(map: Map) {
        if map.JSON["header"] == nil {
            return nil
        }
    }
    public func mapping(map: Map) {
        header <- map["header"]
        body <- map["body"]
    }
    
}

public class WSNotificationResponseHeader:NSObject, Mappable {
    
    var path: String?
    
    var req_id: String?
    
    required public init?(map: Map) {
        
    }
    
    public func mapping(map: Map) {
        path <- map["path"]
        req_id <- map["req_id"]
    }
    
}


