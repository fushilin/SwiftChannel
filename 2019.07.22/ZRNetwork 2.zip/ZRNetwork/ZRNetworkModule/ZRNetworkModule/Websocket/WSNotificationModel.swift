//
//  WSNotificationModel.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/18.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit

public class WSNotificationModel: NSObject {
    var path : String
    var data: Any?
    var req_id: String?
    
    init(path: String, req_id: String?, data: Any?) {
        self.path = path
        self.data = data
        self.req_id = req_id
    }
}
