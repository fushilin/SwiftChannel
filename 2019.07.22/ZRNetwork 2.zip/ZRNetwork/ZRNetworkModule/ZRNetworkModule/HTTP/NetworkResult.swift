//
//  NetworkResult.swift
//  CandleStickChart_Swift_Demo
//
//  Created by lam on 2019/7/9.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ObjectMapper


public enum NetworkStatus: String {
    /// 成功
    case success = "000000"
    
    /// 通用错误
    case commErr = "-1"
}


/// 请求返回结果model
public class NetworkResult: NSObject,Mappable {
    
    
    var msg: String? = ""
    
    var code:NetworkStatus = .commErr
    
    var data: Any?
    
    required public init?(map: Map) {
        
    }
    
    public func mapping(map: Map) {
        data <- map["data"]
        msg  <- map["msg"]
        code <- map["code"]
    }
    
    //父类的init方法是必须去实现的
    override init() {
        super.init()
    }
    
    required convenience public init?(coder aDecoder: NSCoder) {
        self.init()
    }
    
    func encode(with aCoder: NSCoder) {
        
    }
}
