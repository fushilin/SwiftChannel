//
//  DataResult.swift
//  ZRNetworkModule
//
//  Created by 1230 on 2019/7/30.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit

class DataResult: NSObject {
    
    
    
      /**
     ({
     currentPage = 20;
     datas =     (
     {
     code = 002169;
     id = 5d39587322cdcc07e0fae08e;
     name = "\U667a\U5149\U7535\U6c14";
     ts = SZ;
     tsCode = "002169.SZ";
     type = 1;
     },
     {
     code = 002170;
     id = 5d39587322cdcc07e0fae08f;
     name = "\U82ad\U7530\U80a1\U4efd";
     ts = SZ;
     tsCode = "002170.SZ";
     type = 1;
     },
     {
     code = 002171;
     id = 5d39587322cdcc07e0fae090;
     name = "\U695a\U6c5f\U65b0\U6750";
     ts = SZ;
     tsCode = "002171.SZ";
     type = 1;
     },
     {
     code = 002172;
     id = 5d39587322cdcc07e0fae091;
     name = "\U6fb3\U6d0b\U5065\U5eb7";
     ts = SZ;
     tsCode = "002172.SZ";
     type = 1;
     },
     {
     code = 002173;
     id = 5d39587322cdcc07e0fae092;
     name = "\U521b\U65b0\U533b\U7597";
     ts = SZ;
     tsCode = "002173.SZ";
     type = 1;
     },
     {
     code = 002174;
     id = 5d39587322cdcc07e0fae093;
     name = "\U6e38\U65cf\U7f51\U7edc";
     ts = SZ;
     tsCode = "002174.SZ";
     type = 1;
     },
     {
     code = 002175;
     id = 5d39587322cdcc07e0fae094;
     name = "*ST\U4e1c\U7f51";
     ts = SZ;
     tsCode = "002175.SZ";
     type = 1;
     },
     {
     code = 002176;
     id = 5d39587322cdcc07e0fae095;
     name = "\U6c5f\U7279\U7535\U673a";
     ts = SZ;
     tsCode = "002176.SZ";
     type = 1;
     },
     {
     code = 002177;
     id = 5d39587322cdcc07e0fae096;
     name = "\U5fa1\U94f6\U80a1\U4efd";
     ts = SZ;
     tsCode = "002177.SZ";
     type = 1;
     },
     {
     code = 002178;
     id = 5d39587322cdcc07e0fae097;
     name = "\U5ef6\U534e\U667a\U80fd";
     ts = SZ;
     tsCode = "002178.SZ";
     type = 1;
     }
     );
     pageSize = 10;
     totalPage = 160;
     totalRecord = 1599;
     })
     */
    
    
}
