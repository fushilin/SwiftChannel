//
//  JerryAlamRequest.swift
//  moyo-ceshi-01
//
//  Created by 我演示 on 2019/7/9.
//  Copyright © 2019 世霖mac. All rights reserved.
//

import Foundation
import Alamofire



class JerryAlamRequest: NSObject {

    
}
