//
//  OptionTableViewCell.swift
//  ZRNetworkModule
//
//  Created by 1230 on 2019/8/1.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit

class OptionTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
