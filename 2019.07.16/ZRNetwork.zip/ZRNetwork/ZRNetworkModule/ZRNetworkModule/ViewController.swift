//
//  ViewController.swift
//  jerry-ceshi-sorkect
//
//  Created by 我演示 on 2019/7/12.
//  Copyright © 2019 我演示. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    let socket = WebsocketManager.default
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // print(self.sign.jerry_socketIsConnert())
        
        //        self.view.backgroundColor =  UIColor.green
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       socket.connect()
        
        //        self.sign.jerry_creatSocketConnect()
        //        sign.disConnectBackNow()
        //        sign.jerry_socketDisConnect()
        //        let uuid = UUID().uuidString
        //        print(uuid)
        //        uuid.md5()  字符串加密， 然后确定消息，生成json数据类型传递
        
        
        //        //数组转json
        //        func getJSONStringFromArray(array:NSArray) -> String {
        //
        //            if (!JSONSerialization.isValidJSONObject(array)) {
        //                print("无法解析出JSONString")
        //                return ""
        //            }
        //
        //            let data : NSData! = try? JSONSerialization.data(withJSONObject: array, options: []) as NSData!
        //            let JSONString = NSString(data:data as Data,encoding: String.Encoding.utf8.rawValue)
        //            return JSONString! as String
        //
        //        }
        
        
        
        
    }
    
    /**
     内容信息测试通过之后，再形成对应的处理
     */
    
    
    
}

