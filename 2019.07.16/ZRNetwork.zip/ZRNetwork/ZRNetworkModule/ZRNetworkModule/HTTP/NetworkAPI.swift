//
//  NetworkAPI.swift
//  CandleStickChart_Swift_Demo
//
//  Created by lam on 2019/7/9.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import Moya
import ZRBase


public protocol NetworkAPI {
    /// 路径
    var path: String { get }
    /// 参数
    var parameters: [String: Any] {get}
    ///
}

/// 回调
typealias NetworkBlock = (_ requestRst: RequestResult)->()

/// 请求结果
public enum RequestResult {
    case success(NetworkResult)
    case failure(Error)
}

/// 请求措施
let timeoutClosure = {(endpoint: Endpoint, closure: MoyaProvider<Network>.RequestResultClosure) -> Void in
    
    if var urlRequest = try? endpoint.urlRequest() {
        urlRequest.timeoutInterval = 20
        closure(.success(urlRequest))
    } else {
        closure(.failure(MoyaError.requestMapping(endpoint.url)))
    }
}

/// 载体
class Network<T: NetworkAPI> {
    
    /// 请求体
    let moya = MoyaProvider<Network>(requestClosure:timeoutClosure)
    
    /// 请求API
    var api: NetworkAPI?
    
    
    /// 请求
    @discardableResult
    open func request(_ t: NetworkAPI,  callbackQueue: DispatchQueue? = DispatchQueue.main,progress: Moya.ProgressBlock? = nil , completion: NetworkBlock?) -> Cancellable {
        self.api = t
        return moya.request(self, callbackQueue: callbackQueue, progress: progress, completion: { (result) in
            switch result {
            case .success(let response):
                /// json数据
                guard let json = String(data: response.data, encoding: .utf8) else {
                    completion?(.failure(NetworkError.toJsonError))
                    return
                }
                
                /// 解析
                guard let rs = NetworkResult(JSONString: json) else {
                    completion?(.failure(NetworkError.toJsonError))
                    return
                }
                
                completion?(.success(rs))
                break
                
            case .failure(let error):
                completion?(.failure(error))
                break
            }
        })
    }
}

extension Network: TargetType {
    var baseURL: URL {
        switch ConfigurationManager.default.current {
        case .DEV:
            return URL(string: "")!
        case .TEST:
            return URL(string: "")!
            
        case .RELEASE:
            return URL(string: "")!
        }
    }
    
    /// 路径
    var path: String {
        if let api = self.api {
            return api.path
        }
        return ""
    }
    
    var method: Moya.Method {
        return .post
    }
    
    var sampleData: Data {
        return Data()
    }
    
    var task: Task {
        
        /// 入参
        var parameters = self.api?.parameters ?? [String: Any]()
        /// 加上时间戳
        parameters["timeStamp"] = Int(Date().timeIntervalSince1970 * 1000.0)
        /// 加上签名
        parameters["sign"] = Signer.signed(parameters)
        
        return .requestParameters(parameters: parameters, encoding: JSONEncoding.default)
    }
    
    var headers: [String : String]? {
        var headers: [String : String] = [:]
        
        // token
        let token = ""
        //        if let userModel = UserManager.sharedInstance.userModel {
        //            token = userModel.accessToken ?? ""
        //        }
        headers["token"] = token
        
        // 系统
        headers["osType"] = "IOS"
        
        // deviceId
        headers["deviceId"] = UIDevice.UUID
        
        //osVersion,系统版本
        headers["osVersion"] = UIDevice.current.systemVersion
        
        //app版本
        headers["appVersion"] = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as? String ?? ""
        
        // 语言
        headers["lang"] = LanguageManager.default.serverLanuage
        
        /// content type
        headers["Content-Type"] = "application/json; charset=utf-8"
        
        return headers
    }
}






