//
//  WebsocketPacket.swift
//  ZRNetworkModule
//
//  Created by 我演示 on 2019/7/17.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ZRBase
/*
 {
 "body" : {
 "dev_id" : "ed87ff5f-ba91-402e-ae06-08d22d1a6d72",
 "timestamp" : 1563348491880,
 "token" : "4940b5c2b6c3b10926b140f5d2503f2b"
 },
 "header" : {
 "language" : "ZN",
 "path" : "auth.auth",
 "req_id" : "28C88C50-0157-47C6-8316-9912C72ADCCD",
 "version" : "1.0.0"
 }
 }
 */

class WebsocketPacket: NSObject {
    typealias PacketBlock = () -> Void

    public var path: String  = ""
    
    public var param: [String : Any]?
    
    public var req_id: Int = 0
    
    
    public var block : (PacketBlock)?
    
    public init(path: String, param:  [String : Any]?, req_id: Int, block:PacketBlock?) {
        self.param = param
        self.path = path
        self.req_id = req_id
        self.block = block
        super.init()
    }
    
    public func packet() -> String {
        var header = [String : Any]()
    
        header["req_id"] = String(self.req_id)
        
        header["path"] = self.path
        
        header["language"] = LanguageManager.default.serverLanuage
        
        header["version"]  = Bundle.main.infoDictionary?["CFBundleVersion"] ?? ""
        
        var dic = [String : Any]()
        
        dic["header"] = header
        
        dic["body"] = param ?? [:]
        
        
        if let  data = try? JSONSerialization.data(withJSONObject: dic, options: []), let json = String(data: data, encoding: .utf8)  {
            
            return json
        }
        return ""
    }
    
    
    ///开启全局定时器任务
    public func startTimer(_ back: (()->Void)) {
        
    }
    
    ///结束定时器任务
    public func stopTimer() {
        
    }
    
}
