//
//  WebsocketManager.swift
//  ZRNetworkModule
//
//  Created by lam on 2019/7/17.
//  Copyright © 2019 lam. All rights reserved.
//

import UIKit
import ZRBase
import Starscream
import ObjectMapper

fileprivate class WSResponse:NSObject, Mappable {
    public var code: String?
    public var msg: String?
    public var path: String?
    public var resp_id: String?
    
    required public init?(map: Map) {
        
    }
    
    public func mapping(map: Map) {
        code <- map["code"]
        msg  <- map["msg"]
        path <- map["path"]
        resp_id <- map["resp_id"]
    }
    
    //父类的init方法是必须去实现的
    override init() {
        super.init()
    }
    
    required convenience public init?(coder aDecoder: NSCoder) {
        self.init()
    }
    
    func encode(with aCoder: NSCoder) {
        
    }
}

public enum WebsocketStatus {
    case unConnect
    case connecting
    case connected
}

open class WebsocketManager {
    let WSAddr = "ws://192.168.1.213:1949"
    ///三分钟时间的间隔

    let PingDuration = 180
    
    ///x重新连接的计数器
    private var reconnectCount = 0
    
    /// 心跳包定时器发送技术
    private var heartBeatTimer:Timer?
    
    /// socket
    fileprivate var  socket :WebSocket
    
    /// 默认未连接
    public var status :WebsocketStatus = .unConnect
    
    /// req id
    public var req_id = 0
    
    private var packets: [WebsocketPacket] = [WebsocketPacket]()
    
    /// 静态初始化
    public static let `default`: WebsocketManager = WebsocketManager()
    
    private init(){
        self.socket = WebSocket.init(url: URL(string: WSAddr)!)
        self.socket.delegate = self
        self.socket.disconnect(forceTimeout: 50, closeCode: 12)
    }

    
    /// 连接
    public func connect() {
        if status == .unConnect {
            socket.connect()
            status = .connecting
        }
    }
    
    ///2: 创建连接
    public   func jerry_creatSocketConnect(){
        if socket.isConnected {
            socket.connect()
        }
    }
    
    ///重新建立j连接的办法 首先判断是不是已经在连接了，要用一个东西去处理，比如说字节进行记录 ,在非使用状态下
    /// 3： 断开连接， 判断条件，如果断开连接，调用情况下才重新连接，或者自动重新连接，这个地方。
    ///3.1 断开连接
    ///3.2 手机进入后台，不自动连接
    public func  jerry_socketDisConnect() {
        socket.disconnect()
        
    }
    
    ///4： 进行重连的样式
    ///4.1 在自动断开的情况下，进行重连，z首先判断是不是存在连接
    ///4.2 在后台的情况下，不进行重新连接
    public func  jerry_socketConnectAgain(){
        guard socket.isConnected  else
        { return  }
        if reconnectCount>5 {
            return
        }
        
        reconnectCount = 0
        socket.connect()
    }
    
    ///5： 判断心跳包开始
    public func jerry_socketHeartBeatStart(){
        let timer = Timer.init(timeInterval: TimeInterval(PingDuration), target: self, selector: #selector(heartBeats), userInfo: nil, repeats: true)
        
        self.heartBeatTimer = timer
        RunLoop.current.add(timer, forMode: RunLoop.Mode.common)
    }
    ///6: 心跳包停止
    private func jerry_socketHeartBeatStop(){
        //需要定时器进行处理 如果有数据，进行数据清理
        socket.disconnect()
        self.heartBeatTimer = nil
    }
    
    @objc func heartBeats(){
        
        ///判断信息的应用是不是正常
        socket.write(string: "123")
    }
    ///6: 超时处理信息
    public func jerry_sockerTimeOut(){
        socket.disconnect(forceTimeout: 10, closeCode: 20)
    }
    private   func  jerry_reconnect(){
        if reconnectCount > 60{
            return
        }
        ///首先先关闭，再连接,应该是取消的
        
        self.jerry_creatSocketConnect()
        
        reconnectCount *= 2
        
    }
}


extension WebsocketManager: WebSocketDelegate {
    
    /// 连接完成
    public func websocketDidConnect(socket: WebSocketClient) {
        ///
        self.status = .connected
        
        ///  鉴权
        var param = [String: Any]()
        
        let uuid = UIDevice.UUID ?? ""
        let timestamp = Int64(Date().timeIntervalSince1970 * 1000.0)
        
        param["dev_id"] = uuid
        param["timestamp"] = timestamp
        let signKey = "069de7990c0c4b8d87f516b7478e9f4a"
        let token = (uuid + String(timestamp) + signKey).md5()
        param["token"] = token
        
        req_id  = req_id + 1
        
        let block : WebsocketPacket.PacketBlock = {
            print("响应包执行完成")
        }
        
        let packet  = WebsocketPacket(path: "auth.auth", param: param, req_id: req_id,block: block)
        socket.write(string: packet.packet())
        print("packet json \(packet.packet())")
        self.packets.append(packet)
        
        
        packet.startTimer { [weak self] in
            //对数据进行处理,根据数据的类型进行处理 ,强制处理数据信息
        
            if self!.packets.count  > 0{
                for pk in self!.packets{
                    pk.stopTimer()
                }
                self!.packets.removeAll()
                self!.socket.disconnect()
                self!.socket.connect()
            }
        }
        
//        packet.stopTimer() 数据超时进行处理
        
//        packet.startTimer { [weak, self]
//            if self.packets.count > 0 {
//                /// 超时
//                for pk  in self.packets {
//                    pk.stopTimer()
//                }
//
//                self.packets .removeAll()
//                self.socket.disconnect()
//                self.socket.connect()
//            }
//        }
    }
    
    /// 断开连接
    public func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        
        /// 手动断开
        if error == nil {
            
            /// 异常断开
        } else {
            
        }
        
        
        self.status = .unConnect
        //        socket.connect()
        //尝试重新连接
        
        print("websocketDidDisconnect")
        print("==============\(error as Any)")
    }
    
    
    /// 接收 string数据
    public func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {
         print(text)
        
        /// 发请求返回相对应的响应包
        if let reps = WSResponse(JSONString: text) {
            let path = reps.path ?? ""
            let resq_id = Int(reps.resp_id ?? "-1")!

            let filters = self.packets.filter { (packet) -> Bool in
                if path == packet.path, resq_id == packet.req_id {
                    return true
                }
                return false
            }
            
            
            if filters.count > 0, let first = filters.first, let index = self.packets.firstIndex(of: first) {
                first.block?()
                first.stopTimer()
                self.packets.remove(at: index)
            }
            
            /// 接收服务器主动推送的数据
        } else {
            /// 通知
        }
        
        print("websocketDidReceiveMessage \(self.packets)")
       
    }
    
    // 接收二进制数据
    public func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        print("websocketDidReceiveData")
        
        //     断开连接10 秒之后生成重新连接
        
        
        
        print(data)
    }
    
    ///自己重写的方法为控制总数信息.断开之后，尝试重新连接
}
