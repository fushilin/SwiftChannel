//
//  ZRSocketModel.swift
//  jerry-ceshi-sorkect
//
//  Created by 我演示 on 2019/7/17.
//  Copyright © 2019 我演示. All rights reserved.
//




public class ZRSocketModel{
    
    /**
     {
     "header" : {
     "req_id" : "a8014a60-28e2-4913-b90e-ef54b7c705e3",
     "path" : "auth.auth",
     "language" : "ZN",
     "version" : "1.0.0"
     },
     "body" : {
     "dev_id" : "ed87ff5f-ba91-402e-ae06-08d22d1a6d72",
     "timestamp" : 1563262278825,
     "token" : "958fc42201d190b4366692442ae4bc49"
     }
     }      Swift的内部类比较鸡肋，在内部类里面不能调用外部类的属性或方法，那么如何解决这个问题，把内部类里面调用外部类的那部分代码方法移动到外部类里面，成为外部类的方法，是一种变通解决方式。
     */
    
    var header: String = "header"
//        = "header"
//    var body: String?
////        = "body"
//    public override init() {
//        self.header = "header"
//        self.body = "body"
//    }
    func useHeader() -> String {
        return header
    }
    

}
